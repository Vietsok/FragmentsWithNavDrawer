# FragmentsWithNavDrawer
Tuto sur les fragments avec l'utilisation d'un navigation drawer
